# Hello ADC

## References and Useful Links
- [MAX10 Analog to Digital Converter User Guide](https://www.intel.com/content/dam/www/programmable/us/en/pdfs/literature/hb/max-10/ug_m10_adc.pdf)
- [Avalon Interface Specifications](https://www.intel.com/content/dam/www/programmable/us/en/pdfs/literature/manual/mnl_avalon_spec.pdf)
- [VHDL Tutorial](http://gmvhdl.com/VHDL.html)

---
*Intel, Quartus, Avalon, and MAX10 are trademarks of Intel Corporation or its subsidiaries. Terasic and DE10 are trademarks of Terasic Technologies Inc.*

